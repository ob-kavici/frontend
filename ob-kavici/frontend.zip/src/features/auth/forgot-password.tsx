const ForgotPassword: React.FC = () => {

    return (
        <div>
            <h1>Forgot Password</h1>
            <p>coming soon...</p>
        </div>
    );
};

export default ForgotPassword;