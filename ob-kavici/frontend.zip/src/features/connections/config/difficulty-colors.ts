export const difficultyColors: Record<number, string> = {
    0: 'bg-yellow-500 dark:bg-yellow-600',
    1: 'bg-green-500 dark:bg-green-600',
    2: 'bg-blue-400 dark:bg-blue-500',
    3: 'bg-purple-400 dark:bg-purple-500',
};